import './App.css';
import Resume from './Components/Resume';


function App() {
  return (
    <div className="App">
      <Resume/>
    </div>
  );
}

export default App;
