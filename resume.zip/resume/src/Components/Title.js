import React from "react";

const Title = (props) => {
  return (
    <>
      <p className="Title">{props.titleName}</p>
    </>
  );
};

export default Title;
