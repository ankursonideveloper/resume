import React from "react";

const Divider = () => {
  return (
    <div className="bold-line divider">
      <hr></hr>
    </div>
  );
};

export default Divider;
